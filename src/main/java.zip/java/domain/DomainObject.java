package domain;

public class DomainObject {
    private String id = null;

    public DomainObject(){};

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
